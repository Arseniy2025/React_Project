import './App.css';
import Search from './components/search/search';
import CurrentWeather from './components/current-weather/current-weather';
import { WEATHER_API_URL, WEATHER_API_KEY } from './api';
import { useState, useEffect } from 'react';
import Forecast from './components/forecast/forecast';

function App() {
  const [currentWeather, setCurrentWeather] = useState(null);
  const [forecast, setForecast] = useState(null);
  const [units, setUnits] = useState(localStorage.getItem('units') || 'metric');
  const [favorites, setFavorites] = useState(
    JSON.parse(localStorage.getItem('favorites') || '[]')
  );

  const fetchWeather = (lat, lon, label) => {
    const currentWeatherFetch = fetch(
      `${WEATHER_API_URL}/weather?lat=${lat}&lon=${lon}&appid=${WEATHER_API_KEY}&units=${units}`
    );
    const forecastFetch = fetch(
      `${WEATHER_API_URL}/forecast?lat=${lat}&lon=${lon}&appid=${WEATHER_API_KEY}&units=${units}`
    );

    Promise.all([currentWeatherFetch, forecastFetch])
      .then(async (response) => {
        const weatherResponse = await response[0].json();
        const forecastResponse = await response[1].json();

        console.log("Данные о погоде:", weatherResponse);
        console.log("Данные о прогнозе:", forecastResponse);

        setCurrentWeather({ city: label, ...weatherResponse });
        setForecast({ city: label, ...forecastResponse });
      })
      .catch((err) => console.log(err));
  };

  const handleOnSearchChange = (searchData) => {
    const [lat, lon] = searchData.value.split(" ");
    fetchWeather(lat, lon, searchData.label);
  };


  useEffect(() => {
    localStorage.setItem('units', units);
    if (currentWeather) {
      const { lat, lon } = currentWeather.coord;
      fetchWeather(lat, lon, currentWeather.city);
    }
    
  }, [units]);

  // избранное
  const isFavorite = (city) =>
    favorites.some((f) => f.label === city);

  const toggleFavorite = () => {
    if (!currentWeather) return;
    const city = { value: `${currentWeather.coord.lat} ${currentWeather.coord.lon}`, label: currentWeather.city };
    let updated;
    if (isFavorite(city.label)) {
      updated = favorites.filter((f) => f.label !== city.label);
    } else {
      updated = [...favorites, city];
    }
    setFavorites(updated);
    localStorage.setItem('favorites', JSON.stringify(updated));
  };

  return (
    <div className="container">
      <Search onSearchChange={handleOnSearchChange} />

      {/* переключатель единиц измерения */}
      <div className="units-switch">
        <button
          className={units === 'metric' ? 'active' : ''}
          onClick={() => setUnits('metric')}
        >°C</button>
        <button
          className={units === 'imperial' ? 'active' : ''}
          onClick={() => setUnits('imperial')}
        >°F</button>
      </div>


      {favorites.length > 0 && (
        <div className="favorites">
          <label className="favorites-title">Избранные города</label>
          {favorites.map((city) => (
            <div className="favorite-item" key={city.label}>
              <span onClick={() => handleOnSearchChange(city)}>{city.label}</span>
              <button onClick={() => {
                const updated = favorites.filter((f) => f.label !== city.label);
                setFavorites(updated);
                localStorage.setItem('favorites', JSON.stringify(updated));
              }}>✕</button>
            </div>
          ))}
        </div>
      )}

      {currentWeather && (
        <button className="fav-btn" onClick={toggleFavorite}>
          {isFavorite(currentWeather.city) ? ' В избранном' : 'В избранное'}
        </button>
      )}

      {currentWeather && <CurrentWeather data={currentWeather} units={units} />}
      {forecast && <Forecast data={forecast} units={units} />}
    </div>
  );
}

export default App;