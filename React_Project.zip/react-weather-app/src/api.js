
export const WEATHER_API_URL = "https://api.openweathermap.org/data/2.5"
export const WEATHER_API_KEY = "0dfb6908cc68980c1520062ecece5366"

export const GEO_API_URL = "https://api.openweathermap.org/geo/1.0"