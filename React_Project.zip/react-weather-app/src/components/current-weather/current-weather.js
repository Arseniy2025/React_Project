import "./current-weather.css"

const CurrentWeather = ({ data, units = 'metric' }) => {
    const tempUnit = units === 'metric' ? '°C' : '°F';
    const windUnit = units === 'metric' ? 'м/с' : 'mph';

    return (
        <div className="weather">
            <div className="top">
                <div>
                    <p className="city">{data.city}</p>
                    <p className="weather-description">{data.weather[0].description}</p>
                </div>
                <img alt="weather" className="weather-icon" src={`icons/${data.weather[0].icon}.png`} />
            </div>
            <div className="bottom">
                <p className="temperature">{Math.round(data.main.temp)}{tempUnit}</p>
                <div className="details">
                    <div className="parameter-row">
                        <span className="parameter-label">Детали</span>
                    </div>
                    <div className="parameter-row">
                        <span className="parameter-label">По ощущениям</span>
                        <span className="parameter-value">{Math.round(data.main.feels_like)}{tempUnit}</span>
                    </div>
                    <div className="parameter-row">
                        <span className="parameter-label">Ветер</span>
                        <span className="parameter-value">{data.wind.speed} {windUnit}</span>
                    </div>
                    <div className="parameter-row">
                        <span className="parameter-label">Влажность</span>
                        <span className="parameter-value">{data.main.humidity}%</span>
                    </div>
                    <div className="parameter-row">
                        <span className="parameter-label">Давление</span>
                        <span className="parameter-value">{data.main.pressure} hPa</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default CurrentWeather;