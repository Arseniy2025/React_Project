import { useState } from "react";
import { AsyncPaginate } from "react-select-async-paginate";
import { GEO_API_URL, WEATHER_API_KEY } from "../../api"; 

const Search = ({ onSearchChange }) => {
    const [search, setSearch] = useState(null);

    const loadOptions = (inputValue) => {

        if (!inputValue) return Promise.resolve({ options: [] });


        return new Promise((resolve) => {
            setTimeout(() => {
                fetch(`${GEO_API_URL}/direct?q=${inputValue}&limit=5&appid=${WEATHER_API_KEY}`)
                    .then(response => {
                        if (!response.ok) throw new Error('Ошибка сети');
                        return response.json();
                    })
                    .then(response => {
                        resolve({
                            options: response.map((city) => ({
                                value: `${city.lat} ${city.lon}`,
                                label: `${city.name}, ${city.country}`,
                            })),
                        });
                    })
                    .catch(err => {
                        console.error("Ошибка при загрузке городов:", err);
                        resolve({ options: [] }); 
                    });
            }, 500);
        });
    };

    const handleOnChange = (searchData) => {
        setSearch(searchData);
        onSearchChange(searchData);
    };

    return (
        <AsyncPaginate
            placeholder="Поиск по городу (например: Moscow)"
            value={search}
            onChange={handleOnChange}
            loadOptions={loadOptions}
            styles={{
                control: (base) => ({
                    ...base,
                    borderRadius: '8px',
                    border: '1px solid #ccc',
                    padding: '5px'
                })
            }}
        />
    );
};

export default Search;