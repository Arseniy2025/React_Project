import { Accordion, AccordionItem, AccordionItemButton, AccordionItemHeading, AccordionItemPanel } from "react-accessible-accordion";
import './forecast.css';

const WEEK_DAYS = ['Понедельник','Вторник','Среда','Четверг','Пятница','Суббота','Воскресенье'];

const Forecast = ({ data, units = 'metric' }) => {
    // Определяем единицы измерения
    const tempUnit = units === 'metric' ? '°C' : '°F';
    const windUnit = units === 'metric' ? 'м/с' : 'mph';

    const dayInWeek = new Date().getDay();
    const forecastDays = WEEK_DAYS.slice(dayInWeek, WEEK_DAYS.length).concat(WEEK_DAYS.slice(0, dayInWeek))

    return (
    <>
        <label className="title">Ежедневный прогноз</label>
        <Accordion allowZeroExpanded>
            {data.list.splice(0,7).map((item, idx) => (
                <AccordionItem key={idx}>
                    <AccordionItemHeading>
                        <AccordionItemButton>
                            <div className="daily-item">
                                <img alt="weather" className="icon-small" src={`icons/${item.weather[0].icon}.png`}/>
                                <label className="day">{forecastDays[idx]}</label>
                                <label className="description">{item.weather[0].description}</label>
                                <label className="min-max">
                                    {Math.round(item.main.temp_min)}{tempUnit} / {Math.round(item.main.temp_max)}{tempUnit}
                                </label>
                            </div>
                        </AccordionItemButton>
                    </AccordionItemHeading>
                    <AccordionItemPanel>
                        <div className="daily-details-grid">
                            <div className="daily-details-grid-item">
                                <label>Давление</label>
                                <label>{item.main.pressure}hPa</label>
                            </div>
                            <div className="daily-details-grid-item">
                                <label>Влажность</label>
                                <label>{item.main.humidity}%</label>
                            </div>
                            <div className="daily-details-grid-item">
                                <label>Облака</label>
                                <label>{item.clouds.all}%</label>
                            </div>
                            <div className="daily-details-grid-item">
                                <label>Скорость ветра</label>
                                <label>{item.wind.speed}{windUnit}</label>
                            </div>
                            <div className="daily-details-grid-item">
                                <label>Уровень моря</label>
                                <label>{item.main.sea_level ?? '—'}м</label>
                            </div>
                            <div className="daily-details-grid-item">
                                <label>Ощущается как</label>
                                {/* Подставляем переменную tempUnit */}
                                <label>{Math.round(item.main.feels_like)}{tempUnit}</label>
                            </div>
                        </div>
                    </AccordionItemPanel>
                </AccordionItem>
            ))}
        </Accordion>
    </>
    )
}
export default Forecast;